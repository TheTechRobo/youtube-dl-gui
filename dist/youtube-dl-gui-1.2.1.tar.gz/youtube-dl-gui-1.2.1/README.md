# youtube-dl-gui
A small GUI frontend for youtube-dl

# Requirements
This has only been tested on Debian/Elive Linux, and will NEVER work on Windows unless there is  some major refactoring or you use Git Bash.

You will need the following package  `mpg321` and also `python3-tkinter`. 

## For Compiling (into a deb):
You need 
- python3-stdeb (apt package)
- nvpy (pip package)

# Credits
## Code
See inside of source code, there's stuff scattered around.
## Song
Pandemic by CHRISRGMFB  
https://chrisrgmfb.com  
Promoted by Royalty Free Planet: https://royaltyfreeplanet.com  
Creative Commons Attribution 3.0

# Instructions
I'll make a deb file later, and write these source code instructions later
